# CIS-455-555
Final Project

Team Members:

Ruijie Mao, dreamfly@sas.upenn.edu

Tejas Shivanand Mane, tmane@seas.upenn.edu


All the code relevent to the project is present in the FinalProject folder. The UI folder only contains previous HW implements used in the intial development phase.

Extra Credit Features Implemented:

HW3 solution adapted to support more efficient computation across multiple iterations for Page Rank and Crawler. 

Usage:

Using the HW3 execution, eg:


To start Crawler:

mvn clean install -DskipTests exec:java@crawlmaster

mvn clean install -DskipTests exec:java@crawlworker1

mvn clean install -DskipTests exec:java@crawlworker2


To start Pagerank computation:

mvn clean install -DskipTests exec:java@pagerankmaster

mvn clean install -DskipTests exec:java@pagerankworker1

mvn clean install -DskipTests exec:java@pagerankworker2

Note: please pay attention to the order of running workers. That is, the machine you run the crawler worker first should run at first in pagerank too. Also, during pagerank status, please set both the number of map thread and the number of reduce thread to 4

To start search engine:

mvn clean install -DskipTests exec:java@ui 
