package edu.upenn.pagerank.cis455.mapreduce.master;

import static spark.Spark.*;

import java.io.*;
import java.net.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.*;
import edu.upenn.pagerank.cis.stormlite.bolt.*;
import edu.upenn.pagerank.cis.stormlite.bolt.PrintBolt;
import edu.upenn.pagerank.cis.stormlite.distributed.*;
import edu.upenn.pagerank.cis.stormlite.spout.*;
import edu.upenn.pagerank.cis.stormlite.tuple.*;
import edu.upenn.pagerank.cis455.mapreduce.worker.WorkerStatus;
import spark.Response;
// right way to thread
// stream
// input or output directory?
// keyswritten
// keyswrite?
public class MasterServer implements Runnable {

  static final long serialVersionUID = 455555001;
  static final int myPort = 61211;
  static List<String> worderAddr = new ArrayList<String>();
  public static final String FILE_SPOUT = "file_spout";
  public static final String MAP_BOLT = "map_bolt";
  public static final String REDUCE_BOLT = "reduce_bolt";

  public static final String FILE_MAP = "file_to_map";
  public static final String MAP_REDUCE = "map_to_reduce";

  public static int numberOfMap;
  public static int numberOfReduce;

  public static Config config = new Config();
  static String requestBody = "";

  public static String masterAddr;
  public URL url;
  static Map<String, WorkerStatus> statusTable = new HashMap<String, WorkerStatus>();
  public void run() {
     try {
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("GET");
      System.out.println(conn.getResponseCode());
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
  static void run(String addr) {
    System.out.println("run job at"  + worderAddr.size());
    URL url = null;
    try {
      url = new URL("http://" + addr + "/runjob");
    } catch (MalformedURLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      throw new RuntimeException("Unable to create remote URL");
    }

    System.out.println("Send worker to" + "http://" + addr + "/runjob");
    MasterServer mo = new MasterServer();
    mo.url = url;
    Thread thread = new Thread(mo);
    thread.start();
    // try {
    //   HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    //   conn.setRequestMethod("GET");
    //   System.out.println(conn.getResponseCode());
    // } catch (IOException e) {
    //   // TODO Auto-generated catch block
    //   e.printStackTrace();
    // }
    //System.out.println("run job at"  + worderAddr.size());
  }

  static void sendToWorker(String addr) {
    URL url = null;
    try {
      url = new URL("http://" + addr + "/definejob");
    } catch (MalformedURLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      throw new RuntimeException("Unable to create remote URL");
    }
    System.out.println("Send worker to" + "http://" + addr + "/definejob");
    HttpURLConnection conn;
    try {
      conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("POST");
      conn.setDoOutput(true);  
      
      OutputStream os = conn.getOutputStream();
      os.write(requestBody.getBytes());

      os.flush();
      os.close();
      System.out.println("Worker Sent" + conn.getResponseCode());
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
// input directory
// output directorys
  static void buildTopo(int i, String addr) {
    // to do send bolt the ip address
    FileSpout spout = new FileSpout();
    MapBolt mapbolt = new MapBolt();
    ReduceBolt reducebolt = new ReduceBolt();

    SenderBolt sendbolt1 = new SenderBolt(); // to map
    SenderBoltReduce sendbolt2 = new SenderBoltReduce(); // to reduce 
    TopologyBuilder builder = new TopologyBuilder();

    PrintBolt printbolt = new PrintBolt();
    spout.filename = spout.filename + Integer.toString(i);

    builder.setSpout(FILE_SPOUT, spout, 1);

    builder.setBolt("send_bolt1", sendbolt1, 1).shuffleGrouping(FILE_SPOUT);

    builder.setBolt(MAP_BOLT, mapbolt, Integer.parseInt(config.get("numOfMapThread")))
    .shuffleGrouping("send_bolt1");

    builder.setBolt(REDUCE_BOLT, reducebolt, Integer.parseInt(config.get("numOfReduceThread")))
    .fieldsGrouping("send_bolt2", new Fields("key"));

    builder.setBolt("send_bolt2", sendbolt2, 1).fieldsGrouping(MAP_BOLT,
        new Fields("key"));

    builder.setBolt("print_bolt", printbolt, 1).firstGrouping(REDUCE_BOLT);   
       
    Topology topo = builder.createTopology();
    WorkerJob workerJob = new WorkerJob(topo, config);

    ObjectMapper om = new ObjectMapper();
    om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    try {
      requestBody = om.writerWithDefaultPrettyPrinter().writeValueAsString(workerJob);
    } catch (JsonProcessingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    };
  }

  final static String html = "<!DOCTYPE html>\n<html>\n" +
  "<head>\n<title>Register account</title></head><body><h1>Please fill in the directory of the files</h1>\n"
  + "<form method=\"POST\" action=\"/status\">\n"
  + "Class Name: <input type=\"text\" name=\"class\"/><br/>\n"
  + "Input Directory: <input type=\"text\" name=\"inputDirectory\"/><br/>\n"
  + "Output Directory: <input type=\"text\" name=\"outputDirectory\"/><br/>\n"
  + "Number of Map Threads: <input type=\"text\" name=\"numOfMapThread\"/><br/>\n"
  + "Number of Reduce Threads: <input type=\"text\" name=\"numOfReduceThread\"/><br/>\n"
  + "<input type=\"submit\" value=\"Summit Job\"/>\n"
  + "</form>\n";
// download file
// save file 
  static int index = 0;
  //public static Map<String, String> workerList = new HashMap<String, String>();
  public static void registerStatusPage() {
    get("/status", (request, response) -> {
        String result = html;
        for (String i: statusTable.keySet()) {
          WorkerStatus ws = statusTable.get(i);
          result += "</p> Worker: " + i + "     " + ws.toString() + "</p>\n";
        }
        result += "</body>\n</html>";
        return result;
    });
    
    post("/status", (request, response) -> {
      numberOfMap = Integer.parseInt(request.queryParams("numOfMapThread"));
      numberOfReduce = Integer.parseInt(request.queryParams("numOfReduceThread"));
      config.clear();

      config.put("job", request.queryParams("class"));
      config.put("reduceClass", request.queryParams("class"));
      config.put("mapClass", request.queryParams("class"));
      config.put("inputDirectory", request.queryParams("inputDirectory"));
      config.put("outputDirectory", request.queryParams("outputDirectory"));
      config.put("numOfMapThread", (request.queryParams("numOfMapThread")));
      config.put("numOfReduceThread", request.queryParams("numOfReduceThread"));

      config.put("master", masterAddr);

      int index = 0;
      config.put("workerList", worderAddr.toString());
      for (String s: worderAddr) {
        //System.out.println("GEt worker status: " + statusTable.get(s).toString());
      //  System.out.println("GEt worker status: " + statusTable.get(s).workerIndex);
        index = Integer.parseInt(statusTable.get(s).workerIndex);
        config.remove("ip");
        config.remove("workerIndex");
        config.put("workerIndex", Integer.toString(index));
        config.put("ip", s);
        buildTopo(index, s);
        sendToWorker(s);
        index++;
      }
      // }
      Thread.sleep(1000);
      //System.out.println("size of " + worderAddr.size());
      for (String s : worderAddr) {
        run(s);
      }
      return "";
    });
    // map.put(url, links);
    // map.put(url, "1");
    post("/workerstatus", (req, res) -> {
    //  System.out.println("Workerstatus got");
      ObjectMapper om = new ObjectMapper();
     // om.enableDefaultTyping();
      WorkerStatus workerStatus = om.readValue(req.body(), WorkerStatus.class);

      workerStatus.addr = req.ip() + ":" + workerStatus.addr;
    //  System.out.println("Status Get worker status: " + workerStatus.toString());
      WorkerStatus tem = statusTable.remove(workerStatus.addr);
      
      if (!worderAddr.contains(workerStatus.addr)) { // if this the first time of registering addr
        worderAddr.add(workerStatus.addr);
        workerStatus.workerIndex = Integer.toString(index);
        System.out.println(worderAddr.size());
        index++;
      } else {
        workerStatus.workerIndex = tem.workerIndex;
      }

      statusTable.put(workerStatus.addr, workerStatus);
      return "";
    });

    get("/shutdown", (req, res) -> {
      for (String i: worderAddr) {
        URL url = new URL(i + "/shutdown");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();
      }
      return "shutdown success";
    });
  }

  /**
   * The mainline for launching a MapReduce Master.  This should
   * handle at least the status and workerstatus routes, and optionally
   * initialize a worker as well.
   * 
   * @param args
   */
    public static void main(String[] args) {
		port(myPort);
      //  DataBase db = new DataBase("../store/0");
		System.out.println("Master node startup ");
		
		// TODO: you may want to adapt parts of edu.upenn.pagerank.cis.stormlite.mapreduce.TestMapReduce
		// here
	//	for ()
		registerStatusPage();
		awaitInitialization();
		// TODO: route handler for /workerstatus reports from the workers
	}
}
  
