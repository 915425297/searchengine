package edu.upenn.pagerank.cis.stormlite.bolt;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.OutputFieldsDeclarer;
import edu.upenn.pagerank.cis.stormlite.TopologyContext;
import edu.upenn.pagerank.cis.stormlite.distributed.SenderBolt;
import edu.upenn.pagerank.cis.stormlite.routers.StreamRouter;
import edu.upenn.pagerank.cis.stormlite.spout.FileSpout;
import edu.upenn.pagerank.cis.stormlite.tuple.Fields;
import edu.upenn.pagerank.cis.stormlite.tuple.Tuple;
import edu.upenn.pagerank.cis455.mapreduce.job.PageRank;
import edu.upenn.pagerank.cis455.mapreduce.worker.WorkerServer;

/**
 * A trivial bolt that simply outputs its input stream to the console
 * 
 * @author zives
 *
 */
public class PrintBolt implements IRichBolt {
    static Logger log = LogManager.getLogger(PrintBolt.class);
    DataBase db;
    Fields myFields = new Fields();
    //public static boolean converged = true;
    /**
     * To make it easier to debug: we have a unique ID for each instance of the
     * PrintBolt, aka each "executor"
     */
    String executorId = UUID.randomUUID().toString();
    int endOfStreamCount = 0;
    public String outputFile;
    public static double current1 = 0;
    public static double current2 = 0;
    @Override
    public void cleanup() {
        // Do nothing

    }

    @Override
    public boolean execute(Tuple input) {
     //   outputFile = WorkerServer.config.get("outputDirectory");
     if (ReduceBolt.reduceEnd >= WorkerServer.reduceThread) {
        //  System.out.println("current reduce End" + ReduceBolt.reduceEnd);
            WorkerServer.status.status = "idle";
      } 

    if (WorkerServer.config.get("workerIndex").compareTo("0") != 0) {
        SenderBolt sb = new SenderBolt(WorkerServer.workerList.get(0), "print_bolt");
        try {
            sb.send(input);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (input.isEndOfStream()) {
            endOfStreamCount++;
        //    System.out.println("Print Bolt received" + endOfStreamCount + " "+ WorkerServer.reduceThread);
            if (endOfStreamCount == WorkerServer.reduceThread) {
                WorkerServer.status.running = false;
            }
        }
        return true;
    } 

     if (!input.isEndOfStream()) {
        String url = input.getStringByField("key");
        String value = input.getStringByField("value");
        
        Double value1 = Double.parseDouble(value);
        if (FileSpout.totalKeyword > 0 && FileSpout.cycleCount == 1) {
            if (db.urlToKeyword.containsKey(url)) {
                int count = Integer.parseInt((String) db.urlToKeyword.get(url));
                value1 = new Double(value1.doubleValue() + ((double) count * current1 / FileSpout.totalKeyword - current1 / db.urlToLinks.size()));
            } else if (db.urlToLinks.containsKey(url)) {
                value1 = new Double(value1.doubleValue() - (double) current1 / db.urlToLinks.size());
               // double current = (double) current1 / db.urlToLinks.size();
                //System.out.println(value1 + " " + current + " " + db.urlToLinks.size());
            }
        }
        //value1 = new Double(Double.round(value1.doubleValue(), 2));
            System.out.println("Print Bolt: " + url + " " + value1);
            Double value2;
            if (FileSpout.cycleCount % 2 == 0) {
                value2 = (Double) db.urlToRankPervious.get(url);
                db.urlToRankAfter.put(url, value1);
            } else {
                value2 = (Double) db.urlToRankAfter.get(url);
                db.urlToRankPervious.put(url, value1);
            }
            List<String> urlList = (List<String>)db.urlToLinks.get(url);
            if (value1.doubleValue() - value2.doubleValue() <= 0.1 
            && value1.doubleValue() - value2.doubleValue() >= -0.1
            && urlList != null
            && !urlList.isEmpty()) {
                PageRank.convergedLink++; // should be in the database
            } else {
                if (urlList != null
                && !urlList.isEmpty()) PageRank.unconvergedLink++;
            }
        
    } else {
        endOfStreamCount++;
       // System.out.println("printbolt" + endOfStreamCount + WorkerServer.reduceThread + WorkerServer.workerList.size());
        if (endOfStreamCount == WorkerServer.reduceThread * WorkerServer.workerList.size()) {
          //  WorkerServer.running = false;
           // FileSpout.cycleCount++;
           synchronized(WorkerServer.status) {
                WorkerServer.status.running = false;
           }
          
          //  System.out.println("end of count received" + WorkerServer.status.running);
        } 
    }
		return true;
	}
// urlToKeyword if no links do not put into database
	@Override
	public void prepare(Map<String, String> stormConf, TopologyContext context, OutputCollector collector) {
        // Do nothing
        // 
        
        try {
			db = new DataBase("../store" + "/" + WorkerServer.id);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
        }

        if (WorkerServer.id == 0 && FileSpout.cycleCount > 0) {
            current1 = 0.5 * db.urlToLinks.size();
            //current2 = ((double) db.urlToLinks.size() - db.urlToKeyword.size()) / ((double) FileSpout.cycleCount * FileSpout.cycleCount * db.urlToLinks.size());
        }
        //System.out.println("Number " + FileSpout.cycleCount + " " +  db.urlToLinks.size() + " " + current1 + " " + current2);
	}

	@Override
	public String getExecutorId() {
		return executorId;
	}

	@Override
	public void setRouter(StreamRouter router) {
		// Do nothing
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(myFields);
	}

	@Override
	public Fields getSchema() {
		return myFields;
	}

}
