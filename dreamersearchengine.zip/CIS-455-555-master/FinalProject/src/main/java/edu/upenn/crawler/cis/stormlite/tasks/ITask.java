package edu.upenn.crawler.cis.stormlite.tasks;

public interface ITask extends Runnable {
	public String getStream();
}
