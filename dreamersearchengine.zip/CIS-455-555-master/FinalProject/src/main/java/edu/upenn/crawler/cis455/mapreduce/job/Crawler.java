package edu.upenn.crawler.cis455.mapreduce.job;

import edu.upenn.crawler.cis.info.RobotsTxtInfo;
import edu.upenn.crawler.cis.info.URLInfo;
import edu.upenn.crawler.cis.stormlite.tuple.Values;
import edu.upenn.crawler.cis455.mapreduce.Context;
import edu.upenn.crawler.cis455.mapreduce.Job;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class Crawler implements Job {
// key is url
// value dummy


    public boolean isOKtoCrawl(String site, int port, boolean isSecure)

    {

        if (!site.endsWith(".xml") && isSecure){
            return true;
        }
        return false;
    }





    @Override
    public void map(String key, String value, Context context, String sourceExecutor) {

        // Your map function for WordCount goes here
        System.out.println("Mapper key = "+key+", value="+value);

//        context.write(key, value, sourceExecutor);

        String url = key;

        URLInfo uin = new URLInfo(url);


        try
        {

            if (isOKtoCrawl(url,uin.getPortNo(), uin.isSecure() ))
            {

                Document doc = Jsoup.connect(url).userAgent("cis455crawler").get();

                Elements links = doc.select("a");
                if (!links.isEmpty())
                {

                    links.stream().map((link) -> link.attr("abs:href")).forEachOrdered((this_url) -> {

                        if (isOKtoParse(new URLInfo(this_url)) && this_url.length() > 5 && (!this_url.contains("moz") || this_url.equals("https://moz.com/top500") ))
                        {

                            if (url.equals("https://moz.com/top500/"))
                            {
                                this_url = this_url.replace("http", "https");
                            }
//                        System.out.println("this_url="+this_url);
                            context.write(this_url, url, sourceExecutor);
                        }
                    });
                }

            }



        }
        catch (IOException ex)
        {

        }
        finally {

        }

    }

    @Override
    public void reduce(String key, Iterator<String> values, Context context, String sourceExecutor) {
        System.out.println("reduce key = "+key+", values="+values);
        // Your reduce function goes here
        context.write(key, "urlToQ", sourceExecutor);
    }



    /**
     * Returns true if it's permissible to fetch the content,
     * eg that it satisfies the path restrictions from robots.txt
     */
    public boolean isOKtoParse(URLInfo url)
    {


        if (url.getDocURL().toLowerCase().endsWith(".png") ||
                url.getDocURL().toLowerCase().endsWith(".jpg") ||
                url.getDocURL().toLowerCase().endsWith(".jpeg")||
                url.getDocURL().toLowerCase().endsWith(".png"))
        {
            return false;
        }
        try
        {
            RobotsTxtInfo rti = getRobotsTxtInfo(url.toRobotsTxt());
            if (rti==null)
            {
                return true;
            }
            ArrayList<String> A ;
            if (rti.getDisallowedLinks("cis455crawler") ==null)
            {
                A = rti.getDisallowedLinks("*");
            }
            else
            {
                A = rti.getDisallowedLinks("cis455crawler");
            }

            if (A==null)
            {
                return false;
            }

            for (int i = 0; i < A.size(); i++)
            {
                if (url.getDocURL().contains(A.get(i)))
                {
                    return false;
                }
            }

            return true;
        }
        catch (Exception e)

        {
            e.printStackTrace();
        }
        finally {

        }

        return false;
    }









    public RobotsTxtInfo getRobotsTxtInfo(String url) throws IOException
    {

        try
        {
            URL oracle = new URL(url);

            InputStreamReader ir = new InputStreamReader(oracle.openStream());
            BufferedReader in = null;
            if (ir != null)
            {
                in = new BufferedReader(ir);
            }

            RobotsTxtInfo rti = new RobotsTxtInfo();

            String inputLine;
            String currentUserAgent = null;
            String Allowed = null;
            String notAllowed = null;
            int crawl_delay = 0;

            if (in != null)
            {
                while ((inputLine = in.readLine()) != null)
                {

                    String temp = inputLine.substring(inputLine.lastIndexOf(": ") + 1).trim();
                    if (inputLine.startsWith("User-agent:"))
                    {
                        currentUserAgent = temp;
                        rti.addUserAgent(currentUserAgent);
                    }
                    if (inputLine.startsWith("Disallow:"))
                    {
                        notAllowed = temp;
                        rti.addDisallowedLink(currentUserAgent, notAllowed);
                    }

                    if (inputLine.startsWith("Allow:"))
                    {
                        Allowed = temp;
                        rti.addAllowedLink(currentUserAgent, Allowed);
                    }

                    if (inputLine.startsWith("Crawl-delay:"))
                    {
                        try
                        {
                            crawl_delay = Integer.parseInt(temp);
                            rti.addCrawlDelay(currentUserAgent, crawl_delay);
                        }
                        catch (Exception e)
                        {
                            rti.addCrawlDelay(currentUserAgent, 0);
                        }
                    }


                }

                in.close();
            }

            return rti;
        }
        catch (Exception e)
        {
            return null;
        }
    }





}
