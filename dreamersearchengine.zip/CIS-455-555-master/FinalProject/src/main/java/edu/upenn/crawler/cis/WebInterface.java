package edu.upenn.crawler.cis;

import edu.upenn.DataBase;
import edu.upenn.crawler.cis.handlers.LogoutHandler;
import edu.upenn.crawler.cis.handlers.SearchHandler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import static spark.Spark.*;


public class WebInterface {


    public static void main(String args[]) {
        if (args.length < 1 || args.length > 2) {
            System.out.println("Syntax: WebInterface {path} {root}");
            System.exit(1);
        }
        
        if (!Files.exists(Paths.get(args[0]))) {
            try {
                Files.createDirectory(Paths.get(args[0]));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
        port(45555);
        DataBase database = new DataBase(args[0]);

//        LoginFilter testIfLoggedIn = new LoginFilter(database);
        
        if (args.length == 2)
        {
            staticFiles.externalLocation("www/");
            staticFileLocation("www/");
        }


        // TODO:  add /register, /logout, /index.html, /, /lookup

//        post("/register", new RegistrationHandler(database));

//        post("/login", new LoginHandler(database));

//        get("/index.html", new IndexHandler(database));
        post("/register", new SearchHandler(database));

         post("/searchHandle", new SearchHandler(database));
//         get("/", new SearchPageHandler());

//        get("/index", new IndexHandler(database));
        get("/logout", new LogoutHandler(database));
//        get("/create/*", new ChannelCreateHandler());

        awaitInitialization();
//        database.close();
    }




}

