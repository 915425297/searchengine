package edu.upenn.crawler.cis.stormlite.distributed;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.crawler.cis.stormlite.OutputFieldsDeclarer;
import edu.upenn.crawler.cis.stormlite.TopologyContext;
import edu.upenn.crawler.cis.stormlite.bolt.IRichBolt;
import edu.upenn.crawler.cis.stormlite.bolt.OutputCollector;
import edu.upenn.crawler.cis.stormlite.routers.StreamRouter;
import edu.upenn.crawler.cis.stormlite.tuple.Fields;
import edu.upenn.crawler.cis.stormlite.tuple.Tuple;
import edu.upenn.crawler.cis455.mapreduce.master.MasterServer;
import edu.upenn.crawler.cis455.mapreduce.worker.WorkerServer;

/**
 * This is a virtual bolt that is used to route data to the WorkerServer
 * on a different worker.
 * // fieldGrouping or other things
 * // emit()
 * //
 * // emit +pushdata
 * @author zives
 *
 */
public class SenderBolt implements IRichBolt {

	static Logger log = LogManager.getLogger(SenderBolt.class);

    /**
     * To make it easier to debug: we have a unique ID for each
     * instance of the WordCounter, aka each "executor"
     */
    String executorId = UUID.randomUUID().toString();
    
	Fields schema = new Fields("key", "value");
	
	public String stream = MasterServer.MAP_BOLT;
	String address;
    ObjectMapper mapper = new ObjectMapper();
	URL url;
	
	TopologyContext context;
	
	boolean isEndOfStream = false;
	
	OutputCollector collector;
	public SenderBolt() {

	}
    public SenderBolt(String address, String stream) {
     	this.stream = stream;
    	this.address = address;
    }
    
	/**
     * Initialization, just saves the output stream destination
     */
    @Override
    public void prepare(Map<String,String> stormConf, 
    		TopologyContext context, OutputCollector collector) {
        mapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		this.context = context;
		this.collector = collector;

    }

    /**
     * Process a tuple received from the stream, incrementing our
     * counter and outputting a result
	 * // can we randomly determine where to go
     */
	int endOfcount = 0;
    @Override
    public synchronized boolean execute(Tuple input) {
		if (input == null) return false;
		if (input.isEndOfStream()) {
			endOfcount++;
		//	System.out.println("Send Bolt EOS addr" + address + "id : " + executorId + " num " + endOfcount);
			for (String addr: WorkerServer.workerList) {
				address = addr;
				try {
					send(input); // boardcasting
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return true;
		}

		String key = (String) input.getValues().get(0);
		int hashCode = key.hashCode();
		int size = WorkerServer.workerList.size();
		if (hashCode < 0) hashCode = -hashCode;
		address = WorkerServer.workerList.get(hashCode % size);
//		System.out.println("Send bolt picked up to map: " + key);
		try {
			send(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
    }
    
    /**
     * Sends the data along a socket
     * 
     * @param stream
     * @param tuple
     * @throws IOException 
     */
    public void send(Tuple tuple) throws IOException {
		// if (WorkerServer.config.get("ip").compareTo(address) == 0) {
		// 	collector.emit(tuple, executorId);
		// 	return;
		// }
		address = address.trim();
		try {
			url = new URL("http://" + address + "/pushdata/" + stream);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("Unable to create remote URL");
		}
    	isEndOfStream = tuple.isEndOfStream();
    	
		log.debug("Sender is routing " + tuple.toString() + " from " + tuple.getSourceExecutor() + " to " + address + "/" + stream);
		
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestProperty("Cookie", "executeid=" + executorId);
		String jsonForTuple = "";
		synchronized(WorkerServer.om) {
			jsonForTuple = WorkerServer.om.writerWithDefaultPrettyPrinter().writeValueAsString(tuple);
		//System.out.println("worker2: " + address);

		}
		conn.setRequestMethod("POST"); 
        conn.setDoOutput(true);
		OutputStream os = conn.getOutputStream();
		os.write(jsonForTuple.getBytes());

		os.flush();
        os.close();		
		conn.getResponseCode();
		// TODO: send this to /pushdata/{stream} as a POST!
		///////////
		conn.disconnect();
    }

    /**
     * Shutdown, just frees memory
     */
    @Override
    public void cleanup() {
    }

    /**
     * Lets the downstream operators know our schema
     */
    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(schema);
    }

    /**
     * Used for debug purposes, shows our executor/operator's unique ID
     */
	@Override
	public String getExecutorId() {
		return executorId;
	}

	/**
	 * Called during topology setup, sets the router to the next
	 * bolt
	 */
	@Override
	public void setRouter(StreamRouter router) {
		// NOP for this, since its destination is a socket
		this.collector.setRouter(router);
	}

	/**
	 * The fields (schema) of our output stream
	 */
	@Override
	public Fields getSchema() {
		return schema;
	}
}
