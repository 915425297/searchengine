package edu.upenn.pagerank.cis455.mapreduce.worker;

import static spark.Spark.*;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import javax.sql.rowset.spi.SyncResolver;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sleepycat.je.DatabaseException;

import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.*;
import edu.upenn.pagerank.cis.stormlite.bolt.*;
import edu.upenn.pagerank.cis.stormlite.distributed.*;
import edu.upenn.pagerank.cis.stormlite.routers.StreamRouter;
import edu.upenn.pagerank.cis.stormlite.spout.*;
import edu.upenn.pagerank.cis.stormlite.tuple.*;
import edu.upenn.pagerank.cis455.mapreduce.RunJobRoute;
import edu.upenn.pagerank.cis455.mapreduce.master.MasterServer;
import spark.Spark;

/**
 * Simple listener for worker creation
 * 
 * @author zives here already started the topology //
 */
public class WorkerServer {
	static Logger log = LogManager.getLogger(WorkerServer.class);

	public static DistributedCluster cluster = new DistributedCluster();

	public static List<TopologyContext> contexts = new ArrayList<>();

	int myPort;
	public static boolean shutdown = false;
	public static DataBase db;
	public static List<String> topologies = new ArrayList<>();
	public static WorkerStatus status = new WorkerStatus();

	public static Thread sendThread;
	public static String currentName = "";
	public static boolean running;
	public static int id;
	public static WorkerJob currentJob;
	public static Config config;
	public static List<String> workerList;
	public static int mapThread = 4;
	public static int reduceThread = 4;
	public static final ObjectMapper om = new ObjectMapper();
	public static WorkerJob workerJob;
	public Topology topo;

	public void buildTopo() {
		FileSpout spout = new FileSpout();
		MapBolt mapbolt = new MapBolt();
		ReduceBolt reducebolt = new ReduceBolt();
	
		SenderBolt sendbolt1 = new SenderBolt(); // to map
		SenderBoltReduce sendbolt2 = new SenderBoltReduce(); // to reduce 
		TopologyBuilder builder = new TopologyBuilder();
	
		PrintBolt printbolt = new PrintBolt();
		//spout.filename = spout.filename + Integer.toString(i);
	
		builder.setSpout(MasterServer.FILE_SPOUT, spout, 1);
	
		builder.setBolt("send_bolt1", sendbolt1, 1).shuffleGrouping(MasterServer.FILE_SPOUT);
	
		builder.setBolt(MasterServer.MAP_BOLT, mapbolt, WorkerServer.mapThread).shuffleGrouping("send_bolt1");
	
		builder.setBolt(MasterServer.REDUCE_BOLT, reducebolt, WorkerServer.reduceThread).fieldsGrouping("send_bolt2", new Fields("key"));
	
		builder.setBolt("send_bolt2", sendbolt2, 1).fieldsGrouping(MasterServer.MAP_BOLT,
			new Fields("key"));
	
		builder.setBolt("print_bolt", printbolt, 1).firstGrouping(MasterServer.REDUCE_BOLT);   
		   
		topo = builder.createTopology();
	}
	
	public WorkerServer(int myPort) throws MalformedURLException {

		log.info("Creating server listener at socket " + myPort);

		buildTopo();
		port(myPort);
		// try {
		// File directory = new File(String.valueOf("~/store"));
		// if (!directory.exists()) directory.mkdirs();
		// db = new DataBase("~/store");
		// } catch (DatabaseException | FileNotFoundException e1) {
		// // TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		// what does objectmapper here do?

		om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		Spark.post("/definejob", (req, res) -> {

			try {
				workerJob = om.readValue(req.body(), WorkerJob.class);
				currentJob = workerJob;
				// MasterServer.masterAddr = workerJob.getConfig().get("master");
				String data = workerJob.getConfig().get("workerList");
				// System.out.println("WorkerList is data: " + data);
				data = data.replace("[", "").replace("]", "");

				workerList = Arrays.asList(data.split(","));
				status.workerIndex = workerJob.getConfig().get("workerIndex");
				id = Integer.parseInt(workerJob.getConfig().get("workerIndex"));
				// for (String i : workerList) {
				// System.out.println("workerlist: " + i);
				// }
					// why several topologies
					MasterServer.config = workerJob.getConfig();
					WorkerServer.config = workerJob.getConfig();
					//cluster = new DistributedCluster();
					mapThread = Integer.parseInt(config.get("numOfMapThread"));
					reduceThread = Integer.parseInt(config.get("numOfReduceThread"));
					log.info("Processing job definition request" + workerJob.getConfig().get("job") + " on machine "
							+ workerJob.getConfig().get("workerIndex"));
					// System.out.println("Processing job definition request" +
					// workerJob.getConfig().get("job") +
					// " on machine " + workerJob.getConfig().get("workerIndex"));
					if (WorkerServer.id == 0) testcase();
					status.currentJob = workerJob.getConfig().get("reduceClass");
					
					contexts.add(cluster.submitTopology(currentName = workerJob.getConfig().get("job"), workerJob.getConfig(), 
								topo));
					// contexts.add(cluster.submitTopology(currentName = workerJob.getConfig().get("job"),
					// 		workerJob.getConfig(), workerJob.getTopology()));

					// // Add a new topology
					// synchronized (topologies) {
					// 	topologies.add(workerJob.getConfig().get("job"));
					// }
					
					System.out.println("test case built");
					// RunJobRoute runner = new RunJobRoute(cluster);
					// runner.handle(req, res);
				return "Job launched";
			} catch (IOException e) {
				e.printStackTrace();

				// Internal server error
				res.status(500);
				return e.getMessage();
			}
			// grab
		});

		Spark.get("/runjob", new RunJobRoute(cluster));

		Spark.post("/pushdata/:stream", (req, res) -> {
			Tuple tuple = null;

			try {
				String stream = req.params(":stream");
				log.debug("Worker received: " + req.body());
				tuple = om.readValue(req.body(), Tuple.class);

				log.info("Worker received: " + tuple + " for " + stream);
				// Find the destination stream and route to it
				StreamRouter router = cluster.getStreamRouter(stream);

				
				// if (contexts.isEmpty())
				// 	log.error("No topology context -- were we initialized??");

				TopologyContext ourContext;

				while (true) {
					synchronized(WorkerServer.contexts) {
						if (!WorkerServer.contexts.isEmpty()) {
							ourContext = WorkerServer.contexts.get(WorkerServer.contexts.size() - 1);
							break;
						}	
					}
				}
					
					 	
					
				//System.out.println("Tuple got from push data: " + tuple);
				// Instrumentation for tracking progress
			//	System.out.println("s" + stream);
				//if (router == null) System.out.println("router is null");
				//if (tuple == null) System.out.println("tuple is null");
				if (!tuple.isEndOfStream())
					ourContext.incSendOutputs(router.getKey(tuple.getValues()));
				String sourceExecutor = req.cookie("executeid");
				if (tuple.isEndOfStream()) {
					//System.out.println("push data EOS received" + tuple + req.cookie("executeid"));
					router.executeEndOfStream(ourContext, sourceExecutor);
				}
				// TODO: handle tuple vs end of stream for our *local nodes only*
				// Please look at StreamRouter and its methods (execute, executeEndOfStream,
				// executeLocally, executeEndOfStreamLocally)
				else
					router.execute(tuple, ourContext, sourceExecutor);
				return "OK";
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println();
				res.status(500);
				return e.getMessage();

		}
		});

		Spark.get("/shutdown", (req, res) -> {
			shutdown();
			WorkerServer.sendThread.yield();
			Thread.yield();
			return "";
		});
	}

	public static void createWorker(Map<String, String> config) {
		if (!config.containsKey("workerList"))
			throw new RuntimeException("Worker spout doesn't have list of worker IP addresses/ports");

		if (!config.containsKey("workerIndex"))
			throw new RuntimeException("Worker spout doesn't know its worker ID");
		else {
			String[] addresses = WorkerHelper.getWorkers(config);
			String myAddress = addresses[Integer.valueOf(config.get("workerIndex"))];

			log.debug("Initializing worker " + myAddress);

			URL url;
			try {
				url = new URL(myAddress);

				new WorkerServer(url.getPort());
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void shutdown() {
		synchronized (topologies) {
			for (String topo : topologies)
				cluster.killTopology(topo);
		}
		cluster.shutdown();
	}

	public static void testcase() {
		// DataBase db = null;
		// try {
		// 	System.out.println(WorkerServer.id);
		// 	db = new DataBase("../store" + "/" + WorkerServer.id);
		// } catch (Exception e) {
		// 	// TODO Auto-generated catch block
		// 	e.printStackTrace();
		// }
		
		// db.urlToRankAfter.put("a", new Double(1));
		// db.urlToRankAfter.put("b", new Double(1));
		// db.urlToRankAfter.put("c", new Double(1));
		// db.urlToRankAfter.put("d", new Double(1));
		// db.urlToRankPervious.put("a", new Double(1));
		// db.urlToRankPervious.put("b", new Double(1));
		// db.urlToRankPervious.put("c", new Double(1));
		// db.urlToRankPervious.put("d", new Double(1));
		// List<String> list1 = new ArrayList<String>();
		// List<String> list2 = new ArrayList<String>();
		// List<String> list3 = new ArrayList<String>();
		// List<String> list4 = new ArrayList<String>();
		// list1.add("b");
		// list1.add("c");
		// list1.add("d");
		// list2.add("a");
		// list2.add("d");
		// list3.add("b");
		// //list4.add("b");
		// db.urlToLinks.put("a", list1);
		// db.urlToLinks.put("b", list2);
		// db.urlToLinks.put("c", list3);
		// //db.urlToLinks.put("d", list4);
		// db.urlToKeyword.put("a", "25");
		// db.urlToKeyword.put("b", "10");
	}
	/**
	 * Simple launch for worker server.  Note that you may want to change / replace
	 * most of this.
	 * 
	 * @param args
	 * @throws MalformedURLException
	 */
	public static void main(String args[]) throws MalformedURLException {
		if (args.length < 1) {
			System.out.println("Usage: WorkerServer [port number]");
			System.exit(1);
		}
		
		
		int myPort = Integer.valueOf(args[0]);
		
		System.out.println("Worker node startup, on port " + myPort);
		
		WorkerServer worker = new WorkerServer(myPort);

		MasterServer.masterAddr = args[1];
		if (!MasterServer.masterAddr.startsWith("http://")) {
			MasterServer.masterAddr = "http://" + MasterServer.masterAddr;
		}
		status.addr = args[0];
		StatusSender ss = new StatusSender();
		WorkerServer.sendThread = new Thread(ss);
		WorkerServer.sendThread.start();
	//	testcase();
		// TODO: you may want to adapt parts of edu.upenn.pagerank.cis.stormlite.mapreduce.TestMapReduce
		// here
		Spark.awaitInitialization();
	}
}
