package edu.upenn.crawler.cis.stormlite.bolt;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;

import com.sleepycat.collections.StoredSortedMap;
import edu.upenn.crawler.cis.info.URLInfo;
import edu.upenn.DataBase;
import edu.upenn.crawler.cis.stormlite.tuple.Values;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.crawler.cis.stormlite.OutputFieldsDeclarer;
import edu.upenn.crawler.cis.stormlite.TopologyContext;
import edu.upenn.crawler.cis.stormlite.bolt.IRichBolt;
import edu.upenn.crawler.cis.stormlite.bolt.OutputCollector;
import edu.upenn.crawler.cis.stormlite.distributed.*;
import edu.upenn.crawler.cis.stormlite.distributed.SenderBolt;
import edu.upenn.crawler.cis.stormlite.routers.StreamRouter;
import edu.upenn.crawler.cis.stormlite.tuple.Fields;
import edu.upenn.crawler.cis.stormlite.tuple.Tuple;
import edu.upenn.crawler.cis455.mapreduce.worker.WorkerServer;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/**
 * A trivial bolt that simply outputs its input stream to the console
 *
 * @author zives
 *
 */
public class PrintBolt implements IRichBolt {
    static Logger log = LogManager.getLogger(PrintBolt.class);

    Fields myFields = new Fields("key", "value");;

    /**
     * To make it easier to debug: we have a unique ID for each instance of the
     * PrintBolt, aka each "executor"
     */
    // Fields schema = new Fields("key", "value");
    String executorId = UUID.randomUUID().toString();
    int endOfStreamCount = 0;
    public String outputFile;
    private OutputCollector collector;
    private TopologyContext context;
    @Override
    public void cleanup() {
        // Do nothing

    }
    public Integer countKeywords(String s)
    {
        Integer count = 0;

        String slow = s.toLowerCase();
        if (s.contains("car insurance"))
        {
            count++;
        }

        if (s.contains("university of pennsylvania"))
        {
            count++;
        }
        if (s.contains("george washington"))
        {
            count++;
        }
        if (s.contains("travel"))
        {
            count++;
        }
        if (s.contains("apple"))
        {
            count++;
        }
        if (s.contains("brown"))
        {
            count++;
        }
        if (s.contains("amazon"))
        {
            count++;
        }
        if (s.contains("elephant"))
        {
            count++;
        }
        if (s.contains("cat"))
        {
            count++;
        }
        if (s.contains("united states of america"))
        {
            count++;
        }


        return count;
    }






    public boolean isOKtoCrawl(String site, int port, boolean isSecure)

    {

        if (!site.endsWith(".xml") && isSecure){
            return true;
        }
        return false;
    }



    public void shutdown() throws Exception {
        for (String i : WorkerServer.workerList) {
            URL url = new URL(i + "/shutdown");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            int a = conn.getResponseCode();
        }
    }



    @Override
    public boolean execute(Tuple input) {


        synchronized(WorkerServer.status)
        {
//            System.out.println("printbolt input="+ input);

            outputFile = WorkerServer.config.get("outputDirectory");
            if (ReduceBolt.reduceEnd >= WorkerServer.reduceThread) {
                //  System.out.println("current reduce End" + ReduceBolt.reduceEnd);
                WorkerServer.status.status = "idle";
            }
            if (WorkerServer.config.get("workerIndex").compareTo("0") != 0)
            {
                SenderBolt sb = new SenderBolt(WorkerServer.workerList.get(0), "print_bolt");
                try {
                    sb.send(input);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                return true;
            }

            if (!input.isEndOfStream())
            {
                if (WorkerServer.config.get("workerIndex").compareTo("0") == 0)
                {

                    String url = input.getStringByField("key");

                    DataBase db = new DataBase("../store/0");

                    ArrayList<String> arr = (ArrayList<String>) db.geturlToQ().get("urlToQ");

                    db.geturlToQ().remove("urlToQ");

                    if(!arr.contains(url))
                    {
                        arr.add(url);
                    }

                    arr.remove(input.getStringByField("value"));
                    db.geturlToQ().put("urlToQ", arr);

                    db.geturlToRankPervious().put(url, new Double(1));
                    db.geturlToRankAfter().put(url, new Double(1));

                    URLInfo uin = new URLInfo(url);

                    Document doc = null;
                    try {


                        doc = Jsoup.connect(url).userAgent("cis455crawler").get();
                        String pageCon = doc.html();
                        int add = db.addDocument(url, pageCon);
                        System.out.println("adding url="+url);

                        Elements links = doc.select("a");
                        if (!links.isEmpty())
                        {
                            ArrayList<String> linksonPage = new ArrayList<String>();

                            links.stream().map((link) -> link.attr("abs:href")).forEachOrdered((this_url) ->
                            {

                                linksonPage.add(this_url);
                            });
                            if (linksonPage.size() > 0)
                            {
                                db.getUrlToLinks().put(url,linksonPage);
                                Integer count = countKeywords(doc.html());
                                if (count > 0)
                                {
                                    db.geturlToKeyword().put(url, count.toString());

                                }

                            }
//                            System.out.println("keyword writing to DataBase=" + db.geturlToKeyword().get(url));

                        }
                        this.collector.emit(new Values<Object>(url, "urlToQ"), getExecutorId());
                        db.close();

                    } catch (Exception e) {
                        db.close();

                    }

                };

            }
            else
            {
                endOfStreamCount++;

            }

        }



        return true;
    }

    @Override
    public void prepare(Map<String, String> stormConf, TopologyContext context, OutputCollector collector) {
        // Do nothing
        this.collector = collector;
        this.context = context;
    }

    @Override
    public String getExecutorId() {
        return executorId;
    }

    @Override
    public void setRouter(StreamRouter router) {
        // Do nothing
        this.collector.setRouter(router);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(myFields);
    }

    @Override
    public Fields getSchema() {
        return myFields;
    }

}
