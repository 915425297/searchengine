package edu.upenn.pagerank.cis455.mapreduce;

/**
 * Context class as per Hadoop MapReduce -- used
 * to write output from the mapper / reducer
 * 
 * @author ZacharyIves
 *
 */
	class Pair {
	public String value;
	public String sourceExecutor;
	public Pair(String value, String sourceExecutor) {
		this.value = value;
		this.sourceExecutor = sourceExecutor;
	}
	}
public interface Context {

	// Write a key/value pair to the output stream, documenting
	// which source sent it [the sourceExecutor is really for
	// your own testing, and you can set it to a blank string
	// if you prefer]
	void write(String key, String value, String sourceExecutor);
}
