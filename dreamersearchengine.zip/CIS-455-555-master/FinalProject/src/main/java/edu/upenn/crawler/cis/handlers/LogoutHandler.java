package edu.upenn.crawler.cis.handlers;

import edu.upenn.DataBase;
import spark.Request;
import spark.Response;
import spark.Route;

public class LogoutHandler implements Route
{
    DataBase db;
    public LogoutHandler(DataBase db)
    {
        this.db = db;
    }



    @Override
    public Object handle(Request request, Response response) throws Exception
    {
        this.db.close();
        System.exit(1);
        return "Closed Database";
    }
}
