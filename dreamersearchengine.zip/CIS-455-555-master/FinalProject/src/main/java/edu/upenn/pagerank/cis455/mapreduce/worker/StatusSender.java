package edu.upenn.pagerank.cis455.mapreduce.worker;

import java.io.*;
import java.net.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;

import edu.upenn.pagerank.cis455.mapreduce.master.MasterServer;

public class StatusSender implements Runnable {
    public String masterAddr = MasterServer.masterAddr + "/workerstatus";

    public void run() {
        while (!WorkerServer.shutdown) {
        
        String requestBody = "";
        final ObjectMapper om = new ObjectMapper();
            //System.out.println(masterAddr);
        // try {
        //     requestBody = om.writerWithDefaultPrettyPrinter().writeValueAsString(WorkerServer.status);
        // } catch (JsonProcessingException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }

        URL url = null;
        
        try {
            url = new URL(masterAddr);
         } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        //System.out.println("2");
        try {
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Content-Type", "application/json");
            //conn.setRequestProperty("Cookie", "executeid=" + executorId);
            synchronized(WorkerServer.status) {
                requestBody = 
                om.writerWithDefaultPrettyPrinter().writeValueAsString(WorkerServer.status); 
            }
            
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
           // conn.connect();
            
             OutputStream os = conn.getOutputStream();
            os.write(requestBody.getBytes());
    
            os.flush();
            os.close();
            conn.getResponseCode();
           // System.out.println();
            // TODO: send this to /pushdata/{stream} as a POST!
            ///////////
            
            conn.disconnect();
            
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }     
       // System.out.println("3");   
         try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }    
        }
       
    }   
}