package edu.upenn.crawler.cis.handlers;

import spark.Filter;
import spark.Request;
import spark.Response;
import spark.Route;

public class SessionHandler implements Filter
{

    @Override
    public void handle(Request request, Response response) throws Exception {

        if (request.session(false) == null)
        {
            response.redirect("/login-form.html");
        }
        else
        {
            handle(request, response);
        }

    }
}
