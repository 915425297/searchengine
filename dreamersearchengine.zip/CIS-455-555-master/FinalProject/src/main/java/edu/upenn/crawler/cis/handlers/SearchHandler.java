package edu.upenn.crawler.cis.handlers;

import com.sleepycat.collections.StoredSortedMap;
import edu.upenn.DataBase;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import spark.Request;
import spark.Response;
import spark.Route;

import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class SearchHandler implements Route
{
    DataBase db;

    public SearchHandler(DataBase db)
    {
        this.db = db;
    }

    public static HashMap<String, Double> sortByValue(SortedMap<String, Double> hm)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Double> > list =
                new LinkedList<Map.Entry<String, Double> >(hm.entrySet());

        // Sort the list
        Collections.sort(list, new Comparator<Map.Entry<String, Double> >() {
            public int compare(Map.Entry<String, Double> o1,
                               Map.Entry<String, Double> o2)
            {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });


        // put data from sorted list to hashmap
        HashMap<String, Double> temp = new LinkedHashMap<String, Double>();
        for (Map.Entry<String, Double> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    public boolean isValid(String url) {
        try {
            URL u = new URL(url); // this would check for the protocol
            u.toURI();
            return true;
        } catch (Exception ex) { }
        return false;
    }



    @Override
    public Object handle(Request request, Response response) throws Exception {

        response.type("text/html");




        File f = new File("www/Urls.txt");
        if(! (f.exists() && !f.isDirectory()))
        {
            StoredSortedMap geturlToRankAfter = db.geturlToRankAfter(); // hash to content
            FileWriter writer = new FileWriter("www/Urls.txt");

            int countb = 0;
            for (Object en : geturlToRankAfter.keySet()) {

                if (countb > 2){
                    writer.write((String) en + System.lineSeparator());
                }

                countb++;
            }
            writer.close();
//            db.close();


        }

        Scanner s = new Scanner(new File("www/Urls.txt"));
        ArrayList<String> list = new ArrayList<String>();
        while (s.hasNext()){
            list.add(s.next());
        }
        s.close();

        SortedMap<String, Double> geturlToRankAfter = new TreeMap<>();


        for (int counter = 0; counter < list.size(); counter++)
        {

            geturlToRankAfter.put(list.get(counter), (double) (1.0/(new Random().nextInt(10000) +1)));

        }




        long startTime = System.currentTimeMillis();


        Map<String, Double> sortedurls = sortByValue(geturlToRankAfter);

        long endTime = System.currentTimeMillis();

        System.out.println("Time for sorting took " + (endTime - startTime) + " milliseconds");


        startTime = System.currentTimeMillis();

        int results_perPage = 10;
        int currentPageNo = 0;

        String returntext = "";
        returntext = returntext + "<form method=\"POST\" action=\"/searchHandle\" style=\"margin:auto;max-width:300px\">\n" +
                "  <input type=\"text\" placeholder=\"Search..\" name=\"search\">\n" +
                "  <input type=\"submit\" value=\"Search\"/>\n" +
                "</form>";

        int count = 0;

        for (String url: sortedurls.keySet())
        {

            if (isValid(url))
            {
                Document document = null;

                try {
                    document = Jsoup.connect(url).timeout(200).get();

                }
                catch (Exception e)
                {

                }

                if(document !=null)
                {
//                System.out.println("url is "+ url);

                    count++;

                    String title = document.title();


//                String description = "";
                    String description = document.body().text();
                    if(description.length() > 300)
                    {
                        description =description.substring(0, 300);
                    }
                    returntext = returntext+ "<div style=\"background-color: white;\">" + "<p><a href="+url+">"+title+"</a>" +"</p> " + "<p style=\"display: block; margin-left:1em; padding-right: 50em;\">"+description+"</p></div>" ;



                }

                if (count > 10)
                {
                    break;
                }

            }


        }


        long endTime2 = System.currentTimeMillis();

        System.out.println("Time for displaying results took " + (endTime2 - startTime) + " milliseconds");



//        htmlpage = htmlpage + returntext;
//        htmlpage = htmlpage + "</body>\n" +
//                "</html> \n";

//        Files.writeString(Paths.get("testResults.html"), returntext);
//        response.redirect("testResults.html");

        return returntext;
    }
}
