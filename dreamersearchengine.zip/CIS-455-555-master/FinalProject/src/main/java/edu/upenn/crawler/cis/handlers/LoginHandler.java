package edu.upenn.crawler.cis.handlers;

import edu.upenn.DataBase;
import spark.Request;
import spark.Route;
import spark.Response;
import spark.HaltException;

public class LoginHandler implements Route
{
    DataBase db;
    
    public LoginHandler(DataBase db) {
        this.db = db;
    }

    @Override
    public String handle(Request req, Response resp) throws HaltException {
        String user = req.queryParams("username");
        String pass = req.queryParams("password");

        return "";
    }
}
