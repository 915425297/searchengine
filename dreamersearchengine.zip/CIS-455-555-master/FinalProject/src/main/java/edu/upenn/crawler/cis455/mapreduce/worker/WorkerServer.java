package edu.upenn.crawler.cis455.mapreduce.worker;

import static spark.Spark.*;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import edu.upenn.DataBase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sleepycat.je.DatabaseException;

import edu.upenn.crawler.cis.stormlite.*;
import edu.upenn.crawler.cis.stormlite.distributed.*;
import edu.upenn.crawler.cis.stormlite.routers.StreamRouter;
import edu.upenn.crawler.cis.stormlite.tuple.Tuple;
import edu.upenn.crawler.cis455.mapreduce.RunJobRoute;
import edu.upenn.crawler.cis455.mapreduce.master.MasterServer;
import spark.Spark;

/**
 * Simple listener for worker creation
 * 
 * @author zives here already started the topology //
 */
public class WorkerServer {
	static Logger log = LogManager.getLogger(WorkerServer.class);

	public static DistributedCluster cluster = null;

	List<TopologyContext> contexts = new ArrayList<>();

	int myPort;
	public static boolean shutdown = false;
	public static DataBase db;
	static List<String> topologies = new ArrayList<>();
	public static WorkerStatus status = new WorkerStatus();

	public static Thread sendThread;
	public static String currentName = "";

	public static int id;
	public static WorkerJob currentJob;
	public static Config config;
	public static List<String> workerList;
	public static int mapThread;
	public static int reduceThread;
	public static final ObjectMapper om = new ObjectMapper();
	public WorkerServer(int myPort) throws MalformedURLException {

		log.info("Creating server listener at socket " + myPort);

		port(myPort);
		// try {
		// 	File directory = new File(String.valueOf("~/store"));
		// 	if (!directory.exists()) directory.mkdirs();
		// 	db = new DataBase("~/store");
		// } catch (DatabaseException | FileNotFoundException e1) {
		// 	// TODO Auto-generated catch block
		// 	e1.printStackTrace();
		// }
		// what does objectmapper here do?
    	
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        Spark.post("/definejob", (req, res) -> {
	        	
	        	WorkerJob workerJob;
				try {
					workerJob = om.readValue(req.body(), WorkerJob.class);
					currentJob = workerJob;
					//MasterServer.masterAddr = workerJob.getConfig().get("master");
					String data = workerJob.getConfig().get("workerList");
				//	System.out.println("WorkerList is data: " + data);
					data = data.replace("[","").replace("]","");
					
					workerList = Arrays.asList(data.split(","));
					status.workerIndex = workerJob.getConfig().get("workerIndex");
					id = Integer.parseInt(workerJob.getConfig().get("workerIndex"));
					// for (String i : workerList) {
					// 	System.out.println("workerlist: " + i);
					// }
		        	try {
						// why several topologies
						MasterServer.config = workerJob.getConfig();
						WorkerServer.config = workerJob.getConfig();						
						cluster = new DistributedCluster();
						mapThread = Integer.parseInt(config.get("numOfMapThread"));
						reduceThread = Integer.parseInt(config.get("numOfReduceThread"));
		        		log.info("Processing job definition request" + workerJob.getConfig().get("job") +
								" on machine " + workerJob.getConfig().get("workerIndex"));
						//System.out.println("Processing job definition request" + workerJob.getConfig().get("job") +
						//		" on machine " + workerJob.getConfig().get("workerIndex"));
						status.currentJob = workerJob.getConfig().get("reduceClass");
						contexts.add(cluster.submitTopology(currentName = workerJob.getConfig().get("job"), workerJob.getConfig(), 
								workerJob.getTopology()));
						
// Add a new topology
						synchronized (topologies) {
							topologies.add(workerJob.getConfig().get("job"));
						}
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		            return "Job launched";
				} catch (IOException e) {
					e.printStackTrace();
					
					// Internal server error
					res.status(500);
					return e.getMessage();
				} 
	        	// grab 
        });
        
        Spark.get("/runjob", new RunJobRoute(cluster));
        
        Spark.post("/pushdata/:stream", (req, res) -> {
			Tuple tuple = null;

			try {
				String stream = req.params(":stream");
				log.debug("Worker received: " + req.body());
				 tuple = om.readValue(req.body(), Tuple.class);
				
//				System.out.println("Worker received: " + tuple + " for " + stream);
				
				// Find the destination stream and route to it
				StreamRouter router = cluster.getStreamRouter(stream);
				
				if (contexts.isEmpty())
					log.error("No topology context -- were we initialized??");
				
				TopologyContext ourContext = contexts.get(contexts.size() - 1);
//				System.out.println("Tuple got from push data: " + tuple);
				// Instrumentation for tracking progress
				if (!tuple.isEndOfStream())
					ourContext.incSendOutputs(router.getKey(tuple.getValues()));
				String sourceExecutor = req.cookie("executeid");
				if (tuple.isEndOfStream()) {
					System.out.println("push data EOS received" + tuple + req.cookie("executeid"));
					router.executeEndOfStream(ourContext, sourceExecutor);
				}
				// TODO: handle tuple vs end of stream for our *local nodes only*
				// Please look at StreamRouter and its methods (execute, executeEndOfStream, executeLocally, executeEndOfStreamLocally)
				 else router.execute(tuple, ourContext, sourceExecutor);
				return "OK";
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println();
				res.status(500);
				return e.getMessage();
			}
				
        });

		Spark.get("/shutdown", (req, res) -> {
			shutdown();
			WorkerServer.sendThread.yield();
			Thread.yield();
			return "";
		});
	}
	
	public static void createWorker(Map<String, String> config) {
		if (!config.containsKey("workerList"))
			throw new RuntimeException("Worker spout doesn't have list of worker IP addresses/ports");

		if (!config.containsKey("workerIndex"))
			throw new RuntimeException("Worker spout doesn't know its worker ID");
		else {
			String[] addresses = WorkerHelper.getWorkers(config);
			String myAddress = addresses[Integer.valueOf(config.get("workerIndex"))];

			log.debug("Initializing worker " + myAddress);

			URL url;
			try {
				url = new URL(myAddress);

				new WorkerServer(url.getPort());
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void shutdown() {
		synchronized(topologies) {
			for (String topo: topologies)
				cluster.killTopology(topo);
		}
    	cluster.shutdown();
	}

	/**
	 * Simple launch for worker server.  Note that you may want to change / replace
	 * most of this.
	 * 
	 * @param args
	 * @throws MalformedURLException
	 */
	public static void main(String args[]) throws MalformedURLException {
		if (args.length < 1) {
			System.out.println("Usage: WorkerServer [port number]");
			System.exit(1);
		}
		
		int myPort = Integer.valueOf(args[0]);
		
		System.out.println("Worker node startup, on port " + myPort);
		
		WorkerServer worker = new WorkerServer(myPort);

		MasterServer.masterAddr = args[1];
		if (!MasterServer.masterAddr.startsWith("http://")) {
			MasterServer.masterAddr = "http://" + MasterServer.masterAddr;
		}
		status.addr = args[0];
		StatusSender ss = new StatusSender();
		WorkerServer.sendThread = new Thread(ss);
		WorkerServer.sendThread.start();
		// TODO: you may want to adapt parts of edu.upenn.crawler.cis.stormlite.mapreduce.TestMapReduce
		// here
		Spark.awaitInitialization();
	}
}
