package edu.upenn.crawler.cis.handlers;

import spark.Request;
import spark.Response;
import spark.Route;

public class SearchPageHandler implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {

        response.redirect("/search.html");
        return null;
    }
}
