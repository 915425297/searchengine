package edu.upenn.pagerank.cis455.mapreduce.job;

import java.util.*;

import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.spout.FileSpout;
import edu.upenn.pagerank.cis455.mapreduce.Context;
import edu.upenn.pagerank.cis455.mapreduce.Job;
// hear back from every maps
// implement word count create 
public class PageRank implements Job {

	/**
	 * This is a method that lets us call map while recording the StormLite source executor ID.
	 * 
	 */
    DataBase db;
    public static int convergedLink = 0;
    public static int unconvergedLink = 0;
	public PageRank() {

    }
    
	public void map(String key, String value, Context context, String sourceExecutor)
	{
     //   System.out.println("Map Bolt: " + key + value);
        context.write(key, value, sourceExecutor); // emits a double
	}
// for (Object i : db.urlToDocId.keyset()) {
    // String docId = db.urlToDocId.get(i);
//} 
	/**
	 * This is a method that lets us call map while recording the StormLite source executor ID.
	 * 
	 */
    
	public void reduce(String key, Iterator<String> values, Context context, String sourceExecutor)
	{
		// Your reduce function goes here
        double sum = 0;
        Iterator<String> flag = values;
        while(flag.hasNext()) {
            sum += Double.parseDouble(flag.next());
        }
        sum = sum * 0.75 + 0.25;
        context.write(key, Double.toString(sum), sourceExecutor);
    }

    // to be run on master server
    public boolean isConverge() {
        int number = 0;// input from db
        int number1 = 0;
    // for go through the page rank result in the data base
        for (Object i : db.urlToRankPervious.keySet()) {
            Double score1 = (Double) db.urlToRankPervious.get(i);
            Double score2 = (Double) db.urlToRankAfter.get(i);
            if (!db.urlToLinks.containsKey((String) i)) continue;
            if (score1 - score2 < 0.1) number++;
            number1++;
        }

        if (number < number1 * 0.9) return true;
        return false;
    }

// before the page rank mapreduce happens
    // public void prepare() {
    //     convergedLink = 0;
    //     unconvergedLink = 0;
    //     // run the mapreduce stuff

    // }

    // public void pageRankInterface() {
    //     while(!isConverge()) {
    //         // submit jobs
    //         // run the job in the mapreduce again 
    //     }
    // }
}
