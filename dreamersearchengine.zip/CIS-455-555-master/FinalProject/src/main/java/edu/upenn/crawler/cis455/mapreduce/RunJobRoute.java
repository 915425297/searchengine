package edu.upenn.crawler.cis455.mapreduce;

import spark.Request;
import spark.Response;
import spark.Route;

import java.io.FileNotFoundException;
import java.util.concurrent.Executors;

import com.sleepycat.je.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.crawler.cis.stormlite.Config;
import edu.upenn.DataBase;
import edu.upenn.crawler.cis.stormlite.DistributedCluster;
import edu.upenn.crawler.cis.stormlite.TopologyBuilder;
import edu.upenn.crawler.cis.stormlite.bolt.ReduceBolt;
import edu.upenn.crawler.cis.stormlite.distributed.SenderBolt;
import edu.upenn.crawler.cis455.mapreduce.worker.*;

public class RunJobRoute implements Route {
	static Logger log = LogManager.getLogger(RunJobRoute.class);
	DistributedCluster cluster;
	
	public RunJobRoute(DistributedCluster cluster) {
		this.cluster = cluster;
	}

	@Override
	public Object handle(Request request, Response response) throws Exception {
		log.info("Starting job!");
		System.out.println("starting job");
		cluster = WorkerServer.cluster;
		// TODO: start the topology on the DistributedCluster, which should start the dataflow
		WorkerServer.shutdown = false;
		// try {
		// //	ReduceBolt.db = new DataBase("/vagrant/store");
		// } catch (DatabaseException e) {
		// 	// TODO Auto-generated catch block
		// 	e.printStackTrace();
		// } catch (FileNotFoundException e) {
		// 	// TODO Auto-generated catch block
		// 	e.printStackTrace();
		// }
		//ReduceBolt.db.reduceMap.clear();
		// if (cluster == null) System.out.println("1234");
		// System.out.println(cluster.taskQueue.size());
		//WorkerServer.sendThread.run();
		WorkerServer.status.keysRead = 0;
		WorkerServer.status.keysWritten = 0;
		cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
		cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
		WorkerServer.status.job = WorkerServer.currentName;
		// if (cluster == null) System.out.println("cluster null");
		// System.out.println("s" + cluster.taskQueue.size());
		cluster.startTopology();
		
		return "Started";
	}

}
