package edu.upenn.crawler.cis.stormlite.spout;

import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import com.sleepycat.collections.StoredSortedMap;
import edu.upenn.DataBase;
import edu.upenn.crawler.cis.info.URLInfo;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import edu.upenn.crawler.cis.stormlite.OutputFieldsDeclarer;
import edu.upenn.crawler.cis.stormlite.TopologyContext;
import edu.upenn.crawler.cis.stormlite.routers.StreamRouter;
import edu.upenn.crawler.cis.stormlite.spout.IRichSpout;
import edu.upenn.crawler.cis.stormlite.spout.SpoutOutputCollector;
import edu.upenn.crawler.cis.stormlite.tuple.Fields;
import edu.upenn.crawler.cis.stormlite.tuple.Values;
import edu.upenn.crawler.cis455.mapreduce.master.MasterServer;
import edu.upenn.crawler.cis455.mapreduce.worker.WorkerServer;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/**
 * Simple word spout, largely derived from
 * https://github.com/apache/storm/tree/master/examples/storm-mongodb-examples
 * but customized to use a file called words.txt.
 *
 */
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership. The ASF
 * licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
public class FileSpout implements IRichSpout {
	static Logger log = LogManager.getLogger(FileSpout.class);

	/**
	 * To make it easier to debug: we have a unique ID for each instance of the
	 * WordSpout, aka each "executor"
	 */
	String executorId = UUID.randomUUID().toString();

	public Integer countKeywords(String s)
	{
		Integer count = 0;

		String slow = s.toLowerCase();
		if (s.contains("car insurance"))
		{
			count++;
		}

		if (s.contains("university of pennsylvania"))
		{
			count++;
		}
		if (s.contains("george washington"))
		{
			count++;
		}
		if (s.contains("travel"))
		{
			count++;
		}
		if (s.contains("apple"))
		{
			count++;
		}
		if (s.contains("brown"))
		{
			count++;
		}
		if (s.contains("amazon"))
		{
			count++;
		}
		if (s.contains("elephant"))
		{
			count++;
		}
		if (s.contains("cat"))
		{
			count++;
		}
		if (s.contains("united states of america"))
		{
			count++;
		}


		return count;
	}

	public boolean isOKtoCrawl(String site, int port, boolean isSecure)

	{

		if (!site.endsWith(".xml") && isSecure){
			return true;
		}
		return false;
	}


	public int count = 0;
	/**
	 * The collector is the destination for tuples; you "emit" tuples there
	 */
	SpoutOutputCollector collector;

	/**
	 * This is a simple file reader
	 */
	public String filename;
	BufferedReader reader;


	DataBase db;
	Random r = new Random();

	int inx = 0;
	boolean sentEof = false;

	public FileSpout()
	{


		filename = getFilename();
	}

	public String getFilename() {
		return MasterServer.config.get("inputDirectory") + "/FILE";
	}

	/**
	 * Initializes the instance of the spout (note that there can be multiple
	 * objects instantiated)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		this.collector = collector;

		try
		{
			log.debug("Starting spout for " + filename);
			log.debug(getExecutorId() + " opening file reader");

			// If we have a worker index, read appropriate file among xyz.txt.0, xyz.txt.1,
			// etc.
//			if (conf.containsKey("workerIndex"))
//				reader = new BufferedReader(new FileReader(filename + "." + conf.get("workerIndex")));
//			else
//				reader = new BufferedReader(new FileReader(filename));

			if (WorkerServer.id ==0)
			{
				db = new DataBase("../store/0");

				try
				{
					StoredSortedMap urlToDocId = db.geturlToDocId(); // hash to content
					System.out.println("print stored doc ids");

					for (Object i: urlToDocId.keySet())
					{
						String url = (String) i;
						String docid = (String) db.geturlToDocId().get(i);
						System.out.println("url ="+url + ", docid="+docid);
					}


					StoredSortedMap urlToQ = db.geturlToQ(); // hash to content
					System.out.println("print stored urlToQ");
					ArrayList<String> arr = (ArrayList<String>) db.geturlToQ().get("urlToQ");
					System.out.println("urlQ ="+arr);

					if (db.geturlToDocId().size() ==0)
					{
						String startUrl = "https://moz.com/top500/";
						ArrayList<String> uniqueURL = new ArrayList<String>();
						uniqueURL.add(startUrl);
						System.out.println("adding seed arr="+uniqueURL);

						db.geturlToQ().put("urlToQ", uniqueURL);
						System.out.println("added seed arr="+db.geturlToQ().get("urlToQ"));

						int add = db.addDocument(startUrl, db.getDocument(startUrl));

						db.geturlToRankPervious().put(startUrl, new Double(1));
						db.geturlToRankAfter().put(startUrl, new Double(1));

						URLInfo uin = new URLInfo(startUrl);

						Document doc = null;

						doc = Jsoup.connect(startUrl).userAgent("cis455crawler").get();
						String pageCon = doc.html();
						Elements links = doc.select("a");
						if (!links.isEmpty())
						{
							ArrayList<String> linksonPage = new ArrayList<String>();

							links.stream().map((link) -> link.attr("abs:href")).forEachOrdered((this_url) ->
							{

								linksonPage.add(this_url);
							});
							if (linksonPage.size() > 0)
							{
								db.getUrlToLinks().put(startUrl,linksonPage);
								Integer count = countKeywords(doc.html());
								if (count > 0)
								{
									db.geturlToKeyword().put(startUrl, count.toString());

								}

							}

						}


					}

				}
				catch (Exception e)
				{
					e.printStackTrace();
				}

				db.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Shut down the spout
	 */
	@Override
	public void close() {
//		db.close();

		if (reader != null)
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	/**
	 * The real work happens here, in incremental fashion. We process and output the
	 * next item(s). They get fed to the collector, which routes them to targets
	 */
	@Override
	public synchronized boolean nextTuple() {
		if (WorkerServer.id != 0) return true;
		DataBase db2 = new DataBase("../store/0");
		String startUrl = "https://moz.com/top500/";
		ArrayList<String> uniqueURL = new ArrayList<String>();
		uniqueURL.add(startUrl);

		ArrayList<String> arrTemp = (ArrayList<String>) db2.geturlToQ().get("urlToQ");

		if ( this.count==0  && !sentEof)
		{

				try {
					ArrayList<String> arr = (ArrayList<String>) db2.geturlToQ().get("urlToQ");

					if (arr.size() > 0)
					{
						db2.geturlToQ().remove("urlToQ");
						int size = arr.size();
						for (int iter = 0; iter < size; iter ++)
						{
							String url = arr.remove(0);
							count = count + 1;
							this.collector.emit(new Values<Object>(url, "urlToQ"), getExecutorId());
						}
						db2.geturlToQ().put("urlToQ", arr);
						db2.close();

					}

					else if (!sentEof)
					{
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						log.info(getExecutorId() + " finished file " + getFilename() + " and emitting EOS");

					}

				}
				catch (Exception e) {
					e.printStackTrace();
				}
				System.out.println("file spout yields" + executorId);
				//Thread.yield();

			countPlus();
			return true;

		}
		else
		{
			db2.close();

			return false;
		}

	}


	public void countPlus()
	{
		this.count = this.count + 1;
	}
	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("key", "value"));
	}


	@Override
	public String getExecutorId() {

		return executorId;
	}


	@Override
	public void setRouter(StreamRouter router) {
		this.collector.setRouter(router);
	}

}
