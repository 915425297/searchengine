package edu.upenn.pagerank.cis.stormlite.spout;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import com.sleepycat.je.DatabaseException;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.*;
import edu.upenn.pagerank.cis.stormlite.routers.StreamRouter;
import edu.upenn.pagerank.cis.stormlite.spout.IRichSpout;
import edu.upenn.pagerank.cis.stormlite.spout.SpoutOutputCollector;
import edu.upenn.pagerank.cis.stormlite.tuple.Fields;
import edu.upenn.pagerank.cis.stormlite.tuple.Tuple;
import edu.upenn.pagerank.cis.stormlite.tuple.Values;
import edu.upenn.pagerank.cis455.mapreduce.master.MasterServer;
import edu.upenn.pagerank.cis455.mapreduce.worker.WorkerServer;

/**
 * Simple word spout, largely derived from
 * https://github.com/apache/storm/tree/master/examples/storm-mongodb-examples
 * but customized to use a file called words.txt.
 * 
 */
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership. The ASF
 * licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
public class FileSpout implements IRichSpout {
	static Logger log = LogManager.getLogger(FileSpout.class);
	DataBase db;
	public static int cycleCount = 1;
	/**
	 * To make it easier to debug: we have a unique ID for each instance of the
	 * WordSpout, aka each "executor"
	 */
	String executorId = UUID.randomUUID().toString();

	/**
	 * The collector is the destination for tuples; you "emit" tuples there
	 */
	SpoutOutputCollector collector;

	/**
	 * This is a simple file reader
	 */
	public String filename;
	BufferedReader reader;
	Random r = new Random();

	int inx = 0;
	boolean sentEof = false;

	public FileSpout() {
	}

	public String getFilename() {
		return MasterServer.config.get("inputDirectory") + "/FILE";
	}

	/**
	 * Initializes the instance of the spout (note that there can be multiple
	 * objects instantiated)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		this.collector = collector;
		try {
			String dir = "/vagrant/store";
			db = new DataBase("../store" + "/" + WorkerServer.id);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		try {
//			log.debug("Starting spout for " + filename);
//			log.debug(getExecutorId() + " opening file reader");
//
//			// If we have a worker index, read appropriate file among xyz.txt.0, xyz.txt.1,
//			// etc.
//			if (conf.containsKey("workerIndex"))
//				reader = new BufferedReader(new FileReader(filename + "." + conf.get("workerIndex")));
//			else
//				reader = new BufferedReader(new FileReader(filename));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

	/**
	 * Shut down the spout
	 */
	@Override
	public void close() {
		if (reader != null)
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	/**
	 * The real work happens here, in incremental fashion. We process and output the
	 * next item(s). They get fed to the collector, which routes them to targets
	 * // filespout: emit the ranks 
	 * // map: 
	 */
	// not put anything into the urlToLinks if no 
	public static int totalKeyword = 0;
	@Override
	public synchronized boolean nextTuple() {
		String url = null;
		if (WorkerServer.id == 0) {
			if (cycleCount == 1) {
				for (Object j : db.urlToKeyword.keySet()) {
					String p = (String) db.urlToKeyword.get(j);
					totalKeyword += Integer.parseInt(p);
				}
			}
			
			for (Object i : db.urlToLinks.keySet()) {
				List<String> result = (List<String>) db.urlToLinks.get(i);

				if (cycleCount == 1) {
					int count = 0;

					if (result.isEmpty()) {
						db.urlToLinks.remove(i);
						System.out.println("we encounter the empty link in the File Spout, which should not happen");
						continue;
					}

					for (String j : result) {
						if (db.urlToLinks.containsKey(j) && !((List<String>)db.urlToLinks.get(j)).isEmpty()) { // to check whether it has been crawled or not
							count++;
						}
					}

					

					if (count == 0) {
						result.add((String) i);
						//db.urlToLinks.remove(i);
						db.urlToLinks.put((String) i, result);
						db.urlToRankPervious.put((String) i, new Double(0.5));
						db.urlToRankAfter.put((String) i, new Double(0.5));
						count = 1;
					}

					db.unCrawlUrl.put((String) i, new Double((double) count));
				}
				
				for (String j : result) {
					//result.add(j);
					url = j;
					Double score = null;
					if (FileSpout.cycleCount % 2 == 0) {
					//	System.out.println(db.urlToRankPervious.get(url));
						score = (Double) db.urlToRankPervious.get(i);
					} else {
					//	System.out.println(db.urlToRankPervious.get(url));
						score = (Double) db.urlToRankAfter.get(i);
					}
					score = score / ((double) ((Double)db.unCrawlUrl.get(i)).doubleValue());
					// result.add(score.toString());
					System.out.println("FIle Spout output: " + url + " " + score + " " + executorId);
					collector.emit(new Values<Object>(url, score.toString()), executorId);
				}
			}

			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			collector.emitEndOfStream(executorId);
			//System.out.println("File Spout emit end of Stream " + FileSpout.cycleCount + " " + executorId);	
		}
		
		return false;
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
       declarer.declare(new Fields("key", "value"));
    }


	@Override
	public String getExecutorId() {
		
		return executorId;
	}


	@Override
	public void setRouter(StreamRouter router) {
		this.collector.setRouter(router);
	}

}
