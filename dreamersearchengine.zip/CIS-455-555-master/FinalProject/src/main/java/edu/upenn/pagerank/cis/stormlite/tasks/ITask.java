package edu.upenn.pagerank.cis.stormlite.tasks;

public interface ITask extends Runnable {
	public String getStream();
}
