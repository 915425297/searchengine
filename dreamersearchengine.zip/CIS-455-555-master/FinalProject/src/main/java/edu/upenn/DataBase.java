package edu.upenn;

import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.collections.StoredSortedMap;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.persist.EntityCursor;
import com.sleepycat.persist.EntityStore;
import com.sleepycat.persist.StoreConfig;
import com.sleepycat.persist.PrimaryIndex;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.collections.StoredSortedMap;
import com.sleepycat.je.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.*;
import java.util.ArrayList;

public class DataBase
{

    public final String USER_INFO = "USER_INFO";
    public final String URL_CONTENT = "URL_CONTENT";
    public static final String CLASS_CATALOG = "java_class_catalog";
    public Database urlToDocIdDB;
    public Database docIdToDocInfoDB;
    public Database urlToLinksDB;
    public Database urlToQDB;
    public Database urlToRankPerviousDB;
    public Database urlToRankAfterDB;
    public Database reduceMapDB;
    public Database urlToKeywordDB;
    public Database unCrawlUrlDB;
    public StoredClassCatalog catalogDb;
    public StoredSortedMap urlToQ;
    public StoredSortedMap urlToDocId; // hash to content
    public StoredSortedMap docIdToDocInfo;
    public StoredSortedMap urlToLinks;
    public StoredSortedMap urlToRankPervious;
    public StoredSortedMap urlToRankAfter;
    public StoredSortedMap reduceMap;
    public StoredSortedMap urlToKeyword;

    String directory;
    public StoredSortedMap urlLastVisit;
    public StoredSortedMap unCrawlUrl;


    public StoredSortedMap getUrlToLinks()
    {
        return this.urlToLinks;
    }
    public StoredSortedMap geturlToRankPervious()
    {
        return this.urlToRankPervious;
    }
    public StoredSortedMap geturlToRankAfter()
    {
        return this.urlToRankAfter;
    }
    public StoredSortedMap geturlToDocId()
    {
        return this.urlToDocId;
    }
    public StoredSortedMap geturlToKeyword()
    {
        return this.urlToKeyword;
    }
    public StoredSortedMap getdocIdToDocInfo()
    {
        return this.docIdToDocInfo;
    }
    public StoredSortedMap geturlToQ()
    {
        return this.urlToQ;
    }
    public StoredSortedMap getunCrawlUrl()
    {
        return this.unCrawlUrl;
    }


    private static EnvironmentConfig envConfig;
    private static Environment env;



    public DataBase(String directory)
    {
        File dir = new File(directory);

        this.directory = directory;

        if (!dir.exists())
        {
            dir.mkdirs();
        }

        EnvironmentConfig envConfig = new EnvironmentConfig();
        envConfig.setTransactional(true);
        envConfig.setAllowCreate(true);
        env = new Environment(new File(directory), envConfig);


        DatabaseConfig dbConfig = new DatabaseConfig();
        dbConfig.setTransactional(true);
        dbConfig.setAllowCreate(true);

        reduceMapDB = env.openDatabase(null, "urerewt", dbConfig);
        urlToDocIdDB = env.openDatabase(null, USER_INFO, dbConfig);
        docIdToDocInfoDB = env.openDatabase(null, URL_CONTENT, dbConfig);
        urlToLinksDB = env.openDatabase(null, "shit1", dbConfig);
        urlToRankPerviousDB = env.openDatabase(null, "shit6", dbConfig);
        urlToRankAfterDB = env.openDatabase(null, "shit5", dbConfig);
        urlToKeywordDB = env.openDatabase(null, "shit7", dbConfig);
        urlToQDB = env.openDatabase(null, "urlToQ", dbConfig);
        unCrawlUrlDB = env.openDatabase(null, "shisfeget5", dbConfig);

        Database catalogDB = env.openDatabase(null, CLASS_CATALOG,
                dbConfig);

        catalogDb = new StoredClassCatalog(catalogDB);

        urlToDocId = new StoredSortedMap(urlToDocIdDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);

        docIdToDocInfo = new StoredSortedMap(docIdToDocInfoDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);

        urlToLinks = new StoredSortedMap(urlToLinksDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);


        urlToRankPervious = new StoredSortedMap(urlToRankPerviousDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);
        urlToRankAfter = new StoredSortedMap(urlToRankAfterDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);
        reduceMap = new StoredSortedMap(reduceMapDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);

        urlToKeyword = new StoredSortedMap(urlToKeywordDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);

        urlToQ = new StoredSortedMap(urlToQDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);

        unCrawlUrl = new StoredSortedMap(unCrawlUrlDB, new SerialBinding(catalogDb,
                String.class), new SerialBinding(catalogDb, Object.class), true);


        envConfig = new EnvironmentConfig();

        envConfig.setAllowCreate(true);

    }

    public int addDocument(String url, String documentContents) throws UnsupportedEncodingException, NoSuchAlgorithmException {

        boolean dupUrl = false;

        if (this.urlToDocId.containsKey(url))
        {
            dupUrl = true;
        }

        if (dupUrl)
        {
            return -1;
        }

        boolean foundinDB = false;


        if (!foundinDB)
        {
            urlToDocId.put(url, ""+urlToDocId.size());

//            docIdToDocInfo.put(""+urlToDocId.size(), documentContents);
        }

        return 0;
    }


    public String getDocument(String url)
    {
        try
        {
            Document doc = null;
            if ( !(url.endsWith(".xml")||url.endsWith(".XML")) )
            {
                doc = Jsoup.connect(url).userAgent("cis455crawler").get();
                return doc.body().text();
            }
            else
            {
                doc = Jsoup.parse(new URL(url).openStream(), "UTF-8", "", Parser.xmlParser());
                return doc.text();
            }



        } catch (Exception e)
        {
            return null;
        }

    }


    public void close()
    {

        urlToDocIdDB.close();
        docIdToDocInfoDB.close();
        urlToLinksDB.close();
        urlToRankAfterDB.close();
        reduceMapDB.close();
        urlToQDB.close();
        unCrawlUrlDB.close();
        urlToKeywordDB.close();
        urlToRankPerviousDB.close();
        catalogDb.close();
        env.close();
    }
}