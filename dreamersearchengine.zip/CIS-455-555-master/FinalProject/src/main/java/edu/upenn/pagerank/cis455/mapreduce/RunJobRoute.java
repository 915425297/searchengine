package edu.upenn.pagerank.cis455.mapreduce;

import spark.Request;
import spark.Response;
import spark.Route;

import java.io.FileNotFoundException;
import java.util.concurrent.Executors;

import com.sleepycat.je.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.pagerank.cis.stormlite.Config;
import edu.upenn.DataBase;
import edu.upenn.pagerank.cis.stormlite.DistributedCluster;
import edu.upenn.pagerank.cis.stormlite.Topology;
import edu.upenn.pagerank.cis.stormlite.TopologyBuilder;
import edu.upenn.pagerank.cis.stormlite.bolt.*;
import edu.upenn.pagerank.cis.stormlite.distributed.*;
import edu.upenn.pagerank.cis.stormlite.spout.FileSpout;
import edu.upenn.pagerank.cis.stormlite.tuple.Fields;
import edu.upenn.pagerank.cis455.mapreduce.job.PageRank;
import edu.upenn.pagerank.cis455.mapreduce.worker.*;

public class RunJobRoute implements Route {
	static Logger log = LogManager.getLogger(RunJobRoute.class);
	DistributedCluster cluster;
	
	public static final String FILE_SPOUT = "file_spout";
	public static final String MAP_BOLT = "map_bolt";
	public static final String REDUCE_BOLT = "reduce_bolt";
  
	public static final String FILE_MAP = "file_to_map";
	public static final String MAP_REDUCE = "map_to_reduce";
	Topology topo;
	public RunJobRoute(DistributedCluster cluster) {
		this.cluster = new DistributedCluster();
	}

	public void buildTopo() {
		FileSpout spout = new FileSpout();
		MapBolt mapbolt = new MapBolt();
		ReduceBolt reducebolt = new ReduceBolt();
	
		SenderBolt sendbolt1 = new SenderBolt(); // to map
		SenderBoltReduce sendbolt2 = new SenderBoltReduce(); // to reduce 
		TopologyBuilder builder = new TopologyBuilder();
	
		PrintBolt printbolt = new PrintBolt();
		//spout.filename = spout.filename + Integer.toString(i);
	
		builder.setSpout(FILE_SPOUT, spout, 1);
	
		builder.setBolt("send_bolt1", sendbolt1, 1).shuffleGrouping(FILE_SPOUT);
	
		builder.setBolt(MAP_BOLT, mapbolt, WorkerServer.mapThread).shuffleGrouping("send_bolt1");
	
		builder.setBolt(REDUCE_BOLT, reducebolt, WorkerServer.reduceThread).fieldsGrouping("send_bolt2", new Fields("key"));
	
		builder.setBolt("send_bolt2", sendbolt2, 1).fieldsGrouping(MAP_BOLT,
			new Fields("key"));
	
		builder.setBolt("print_bolt", printbolt, 1).firstGrouping(REDUCE_BOLT);   
		   
		topo = builder.createTopology();
	}

	@Override
	public Object handle(Request request, Response response) throws Exception {
		log.info("Starting job!");
		System.out.println("starting job");
		cluster = WorkerServer.cluster;
		// TODO: start the topology on the DistributedCluster, which should start the dataflow
		WorkerServer.shutdown = false;
		// try {
		// //	ReduceBolt.db = new DataBase("/vagrant/store");
		// } catch (DatabaseException e) {
		// 	// TODO Auto-generated catch block
		// 	e.printStackTrace();
		// } catch (FileNotFoundException e) {
		// 	// TODO Auto-generated catch block
		// 	e.printStackTrace();
		// }
		//ReduceBolt.db.reduceMap.clear();
		// if (cluster == null) System.out.println("1234");
		// System.out.println(cluster.taskQueue.size());
		//WorkerServer.sendThread.run();
		WorkerServer.status.keysRead = 0;
		WorkerServer.status.keysWritten = 0;

		WorkerServer.status.job = WorkerServer.currentName;
		// if (cluster == null) System.out.println("cluster null");
		// System.out.println("s" + cluster.taskQueue.size());
		while (PageRank.convergedLink <= PageRank.unconvergedLink * 5
		&& FileSpout.cycleCount <= 100
		&& WorkerServer.id == 0) {
			PageRank.convergedLink = 0;
			PageRank.unconvergedLink = 0;
			synchronized(WorkerServer.status) {
				WorkerServer.status.running = true;
			}
			
			

			
			System.out.println("Cycle added " + FileSpout.cycleCount + " " + WorkerServer.id);
			
			//if (WorkerServer.id == 1) System.out.println("shit2");
			//cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
			//cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
					// Add a new topology

			synchronized (WorkerServer.topologies) {
				WorkerServer.topologies.add(WorkerServer.workerJob.getConfig().get("job"));
			}

			cluster.startTopology();

			while (true) {
				//System.out.println("shit1");
			//	System.out.println("1" + WorkerServer.running);\
				synchronized(WorkerServer.status) {
					if (!WorkerServer.status.running) {
						//System.out.println("s");
						cluster.killTopology("string");
						synchronized(WorkerServer.contexts) {
						WorkerServer.contexts.clear();
						}
						break;
					}
				}
				//System.out.println(WorkerServer.running);
			//System.out.println("converge link and unconverged link : " + PageRank.convergedLink + PageRank.unconvergedLink);
			}

			FileSpout.cycleCount++;
			cluster = new DistributedCluster();
			synchronized(WorkerServer.cluster) {
				WorkerServer.cluster = cluster;
			}
			
			
			WorkerServer.topologies.clear();

			buildTopo();
				
				WorkerServer.contexts.add(cluster.submitTopology(WorkerServer.workerJob.getConfig().get("job"),
				WorkerServer.workerJob.getConfig(), topo));
			
			System.out.println("current condition " + PageRank.convergedLink + " " + PageRank.unconvergedLink);
			//cluster.killTopology(WorkerServer.workerJob.getConfig().get("job"));
		}


		while (WorkerServer.id != 0 && FileSpout.cycleCount <= 100) {

			synchronized(WorkerServer.status) {
				WorkerServer.status.running = true;
			}
			


			//cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
			//cluster.executor_map = Executors.newFixedThreadPool(WorkerServer.mapThread);
			// Add a new topology
			synchronized (WorkerServer.topologies) {
				WorkerServer.topologies.add(WorkerServer.workerJob.getConfig().get("job"));
			}
			System.out.println("Cycle added " + FileSpout.cycleCount + " " + WorkerServer.id);
			cluster.startTopology();

			while (true) {
				//System.out.println("shit1");
			//	System.out.println("1" + WorkerServer.running);\
				synchronized(WorkerServer.status) {
					if (!WorkerServer.status.running) {
						System.out.println("s");
						cluster.killTopology("string");
						synchronized(WorkerServer.contexts) {
							WorkerServer.contexts.clear();
						}
						break;
					}
				}
				//System.out.println(WorkerServer.running);
			
				
			}	
			FileSpout.cycleCount++;
			//WorkerServer.contexts.clear();
			WorkerServer.topologies.clear();

			cluster = new DistributedCluster();
			//System.out.println("Cycle added " + FileSpout.cycleCount + " " + WorkerServer.id);
			buildTopo();
			synchronized(WorkerServer.contexts) {
				//WorkerServer.contexts.clear();
				WorkerServer.contexts.add(cluster.submitTopology(WorkerServer.workerJob.getConfig().get("job"),
				WorkerServer.workerJob.getConfig(), topo));
				synchronized(WorkerServer.cluster) {
					WorkerServer.cluster = cluster;
				}
			}
			

			System.out.println("converge link and unconverged link : " + PageRank.convergedLink + PageRank.unconvergedLink);
			
		}
		Thread.yield();
		return "finished";
	}

}
