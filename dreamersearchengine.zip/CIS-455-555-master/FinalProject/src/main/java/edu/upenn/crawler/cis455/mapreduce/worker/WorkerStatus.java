package edu.upenn.crawler.cis455.mapreduce.worker;

public class WorkerStatus {
    public String addr;
    public String status = "idle";
    public String job = "";
    public int keysWritten = 0;
    public int keysRead = 0;
    public String workerIndex;
    public String currentJob = "";
    public String toString() {
        return "Address: " + addr + "          Worker Status: " + status
        + "         Current Job: " + currentJob
        + "         Keys Written: " + Integer.toString(keysWritten)
        + "         Keys Read: " + Integer.toString(keysRead);
    }
}